print("DilSeSuno bot is starting...")
# Your bot code goes here
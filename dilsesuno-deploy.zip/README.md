# DilSeSuno Deploy Package
This folder is ready to deploy on Render.
- Dockerfile included
- Placeholder app code in app/
- Data folder for GPT model
#!/bin/bash
echo "Downloading GPT4All model..."
wget --no-check-certificate "https://drive.google.com/uc?export=download&id=12kABwqCD7pN3dB5PEUHnYySle9cCAXcI" -O /opt/botpress/models/model.gguf
echo "Download complete."